# HW3
Text Mining Homework 3

See CSV output files for scraping of booking.com.

madrid_no_event.csv Madrid properties where no event is taking place during that week in Barcelona and Madrid.
barcelona_no_event.csv Barcelona properties where no event is taking place during that week in Barcelona and Madrid.
barcelona.csv Barcelona properties where event is taking place during that week in Barcelona and not in Madrid.
madrid.csv Madrid properties where event is taking place during that week in Barcelona and not in Madrid.
